#ifndef HPING3_FIXTYPES_H
#define HPING3_FIXTYPES_H

#ifdef __sun__
typedef char                   int_8_t;
typedef unsigned char          u_int8_t;
typedef short                  int_16_t;
typedef unsigned short         u_int16_t;
typedef int                    int_32_t;
typedef unsigned int           u_int32_t;
#endif

#endif
